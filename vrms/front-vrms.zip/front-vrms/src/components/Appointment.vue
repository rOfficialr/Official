<template>
  <!-- 定义的卡片组件 -->
  <el-card>
    <!-- 面包屑组件 -->
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{path:'/welcome'}">首页</el-breadcrumb-item>
      <el-breadcrumb-item>用户地点管理</el-breadcrumb-item>
      <el-breadcrumb-item>预约地点管理</el-breadcrumb-item>
    </el-breadcrumb>
    <!-- 面板布局 -->
    <el-row :gutter="12">
      <el-col :span="6">
        <!-- 输入框组件 -->
        <el-input clearable @clear="listPage" v-model="username" placeholder="请输入预约人名称查询"></el-input>
      </el-col>
      <el-col :span="6">
        <!-- 按钮组件 -->
        <el-button type="primary" icon="el-icon-search" @click="listPage">查询</el-button>
        <el-button type="success" icon="el-icon-plus" @click="openAddDialog">预约</el-button>
      </el-col>
    </el-row>
    <!-- 定义表格组件 -->
    <el-table :data="tableData">
      <el-table-column prop="username" label="姓名"></el-table-column>
      <el-table-column prop="address" label="预约地点"></el-table-column>
      <el-table-column prop="avcname" label="疫苗名称"></el-table-column>
      <el-table-column prop="appstats" label="预约状态">
        <template slot-scope="scope">
          <el-tag v-if="scope.row.appstats==0" type="success">已预约</el-tag>
          <el-tag v-else-if="scope.row.appstats==1" type="danger">已取消</el-tag>
          <el-tag v-else type="warning">未知</el-tag>
        </template>
      </el-table-column>
      <el-table-column prop="apptime" label="预约时间"></el-table-column>
      <el-table-column prop="stats" label="是否接种">
        <template slot-scope="scope">
          <el-tag v-if="scope.row.stats==0" type="danger">未接种</el-tag>
          <el-tag v-else-if="scope.row.stats==1" type="success">已接种</el-tag>
          <el-tag v-else type="warning">未知</el-tag>
        </template>
      </el-table-column>
      <el-table-column label="接种时间">
        <template slot-scope="scope">
          {{scope.row.mtime}}
        </template>
      </el-table-column>
      <el-table-column prop="remark" label="备注"></el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button v-if="scope.row.stats==0" type="success" @click="update(scope.row)">确认接种</el-button>

        </template>
      </el-table-column>
    </el-table>
    <!-- 分页组件定义 -->
    <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="pager.page"
      :page-sizes="[5, 10, 15, 20]" :page-size="pager.size" layout="total, sizes, prev, pager, next, jumper"
      :total="pager.total">
    </el-pagination>

    <!-- 添加对话框定义 -->
    <el-dialog :visible.sync="addFlag" title="添加预约信息">
      <el-form>

        <el-form-item>
          <el-select v-model="appointment.uid" filterable placeholder="请选择预约人姓名">
            <el-option v-for="item in userList" :key="item.uid" :label="item.username" :value="item.uid">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-select v-model="appointment.addid" filterable placeholder="请选择预约地址">
            <el-option v-for="item in addressList" :key="item.addid" :label="item.address" :value="item.addid">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-select v-model="appointment.avcid" filterable placeholder="请选择疫苗">
            <el-option v-for="item in vaccinesList" :key="item.avcid" :label="item.avcname" :value="item.avcid">
            </el-option>
          </el-select>
        </el-form-item>

      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="addFlag = false">取 消</el-button>
        <el-button type="primary" @click="save">确 定</el-button>
      </div>
    </el-dialog>


  </el-card>
</template>

<script>
  export default { //对外暴露vue对象
    data() { //定义的是vue对象的属性
      return {

        addFlag: false, //定义显示添加对话框的显示标记
        editFlag: false, //定义显示修改对话框的显示标记
        tableData: [], //定义表格中的数据，是一个数组
        pager: { //分页参数传递的pager对象
          page: 1, //从第一条开始分页
          size: 5, //每页显示10条记录
          total: 0 //分页总记录数
        },

        username: '',
        appointment: {
          addid: '',
          appstats: "",
          avcid: '',
          money: '',
          remark: '',
          stats: '',
          uid: ''

        },
        userList: [], //预约人的数组，初始化下拉列表
        vaccinesList: [], //疫苗数组，初始化下拉列表
        addressList: [] //预约地址，初始化下拉列表

      }
    },
    methods: { //用户自定义方法，在此编写
      openAddDialog() {
        this.addFlag = !this.addFlag;

      },
      save(){
        this.$http.post('http://127.0.0.1/appointment/save', this.appointment)
          .then(res => {
            if (res.data.code == 200) {
              this.$message({
                message: res.data.message,
                type: 'success'
              });
              this.editFlag = !this.editFlag; //关闭对话代码
              this.listPage();
              this.administators = {}
            }
          }).catch(e => {
            this.$message.error('错了哦，服务器端未启动');
          })
      },
      update(row) {
        this.appointment = row;
        this.$http.post('http://127.0.0.1/appointment/changeStats', this.appointment)
          .then(res => {
            if (res.data.code == 200) {
              this.$message({
                message: res.data.message,
                type: 'success'
              });
              this.editFlag = !this.editFlag; //关闭对话代码
              this.listPage();
              this.administators = {}
            }
          }).catch(e => {
            this.$message.error('错了哦，服务器端未启动');
          })
      },

      handleCurrentChange(val) {
        console.info('改变分页起始数据' + val)
        this.pager.page = val; //分页起始数据赋值
        this.listPage() //再次调佣分页方法
      },
      handleSizeChange(val) {
        console("改变每页显示的最大条数" + val);
        this.pager.size = val; //改变最大的分页数
        this.listPage(); //再次调佣分页方法
      },
      listPage() { //定义分页方法
        this.$http.get('http://127.0.0.1/appointment/listPage', {
          params: {
            page: this.pager.page,
            size: this.pager.size,
            username: this.username
          }
        }).then(res => {
          console.info(res);
          this.tableData = res.data.data.data; //查询出的数据
          this.pager.total = res.data.data.count; //返回分页统计记录数
          console.info(this.pager.total);
        })
      },
      //查询所有预约注册人信息
      listUsers() {
        this.$http.get('http://127.0.0.1/users/list').then(res => {
          this.userList = res.data.data;
        }).catch(err => {
          this.$message.error('错了哦，服务器端未启动');
        })

      },
      listVaccines() {
        this.$http.get('http://127.0.0.1/vaccines/list').then(res => {
          this.vaccinesList = res.data.data;
        }).catch(err => {
          this.$message.error('错了哦，服务器端未启动');
        })
      },

      listAddress() {
        this.$http.get('http://127.0.0.1/address/list').then(res => {
          this.addressList = res.data.data;
        }).catch(err => {
          this.$message.error('错了哦，服务器端未启动');
        })

      }


    },
    created() { //浏览器在渲染时立即执行该方法中的代码
      this.listPage();
      this.listUsers();
      this.listVaccines()
      this.listAddress()


    }
  }
</script>

<style>
  .el-breadcrumb {
    padding-bottom: 12px;

  }

  .el-pagination {
    padding-top: 12px;
  }
</style>
