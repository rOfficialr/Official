<template>
  <!-- 定义的卡片组件 -->
  <el-card>
    <!-- 面包屑组件 -->
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{path:'/welcome'}">首页</el-breadcrumb-item>
      <el-breadcrumb-item>系统信息管理</el-breadcrumb-item>
      <el-breadcrumb-item>系统日志管理</el-breadcrumb-item>
    </el-breadcrumb>
    <!-- 定义表格组件 -->
    <el-table :data="tableData">
      <el-table-column prop="ip" label="操作IP"></el-table-column>
      <el-table-column prop="optime" label="操作时间"></el-table-column>
      <el-table-column prop="methods" label="操作方法"></el-table-column>
      <el-table-column prop="ddesc" label="方法描述"></el-table-column>
    </el-table>
    <!-- 分页组件定义 -->
    <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="pager.page"
      :page-sizes="[5, 10, 15, 20]" :page-size="pager.size" layout="total, sizes, prev, pager, next, jumper"
      :total="pager.total">
    </el-pagination>

  </el-card>
</template>

<script>
  export default { //对外暴露vue对象
    data() { //定义的是vue对象的属性
      return {
        tableData: [], //定义表格中的数据，是一个数组
        pager: { //分页参数传递的pager对象
          page: 1, //从第一条开始分页
          size: 5, //每页显示10条记录
          total: 0 //分页总记录数
        }
      }
    },
    methods: { //用户自定义方法，在此编写

      handleCurrentChange(val) {
        console.info('改变分页起始数据' + val)
        this.pager.page = val; //分页起始数据赋值
        this.listPage() //再次调佣分页方法
      },
      handleSizeChange(val) {
        console("改变每页显示的最大条数" + val);
        this.pager.size = val; //改变最大的分页数
        this.listPage(); //再次调佣分页方法
      },
      listPage() { //定义分页方法
        this.$http.get('http://127.0.0.1/logs/listPage', {
          params: {
            page: this.pager.page,
            size: this.pager.size
          }
        }).then(res => {
          console.info(res);
          this.tableData = res.data.data.data; //查询出的数据
          this.pager.total = res.data.data.count; //返回分页统计记录数
        }).catch(e => {
          this.$message.error('错了哦，服务器端未启动');
        })
      }

    },
    created() { //浏览器在渲染时立即执行该方法中的代码
      this.listPage();
    }
  }
</script>

<style>
  .el-breadcrumb {
    padding-bottom: 12px;

  }

  .el-pagination {
    padding-top: 12px;
  }
</style>
