<template>
  <!-- 定义的卡片组件 -->
  <el-card>
    <!-- 面包屑组件 -->
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{path:'/welcome'}">首页</el-breadcrumb-item>
      <el-breadcrumb-item>预约信息管理</el-breadcrumb-item>
      <el-breadcrumb-item>疫苗信息管理</el-breadcrumb-item>
    </el-breadcrumb>
    <!-- 面板布局 -->
    <el-row :gutter="12">
      <el-col :span="6">
        <!-- 输入框组件 -->
        <el-input clearable @clear="listPage" v-model="avcname" placeholder="请输入疫苗名称查询"></el-input>
      </el-col>
      <el-col :span="6">
        <!-- 按钮组件 -->
        <el-button type="primary" icon="el-icon-search" @click="listPage">查询</el-button>
        <el-button type="success" icon="el-icon-plus" @click="openAddDialog">添加</el-button>
      </el-col>
    </el-row>
    <!-- 定义表格组件 -->
    <el-table :data="tableData">
      <el-table-column prop="avcname" label="疫苗名称"></el-table-column>
      <el-table-column prop="manufactor" label="生产厂家"></el-table-column>
      <el-table-column prop="mdate" label="生产日期"></el-table-column>
      <el-table-column prop="price" label="单价"></el-table-column>
      <el-table-column prop="instructions" label="使用说明"></el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-tooltip content="点击修改" placement="left">
            <el-button type="warning" circle icon="el-icon-edit" @click="openEditDialog(scope.row)"></el-button>
          </el-tooltip>
          <el-tooltip content="点击删除" placement="right">
            <el-button type="danger" circle icon="el-icon-delete" @click="remove(scope.row)"></el-button>
          </el-tooltip>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页组件定义 -->
    <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="pager.page"
      :page-sizes="[5, 10, 15, 20]" :page-size="pager.size" layout="total, sizes, prev, pager, next, jumper"
      :total="pager.total">
    </el-pagination>

    <!-- 添加对话框定义 -->
    <el-dialog :visible.sync="addFlag" title="添加疫苗信息">
      <el-form :model="vaccines" :rules="rules" ref="vaccines">
        <el-form-item prop="avcname">
          <el-input v-model="vaccines.avcname" placeholder="请输入疫苗名称"></el-input>
        </el-form-item>
        <el-form-item prop="price">
          <el-input v-model="vaccines.price" placeholder="请输入价格"></el-input>
        </el-form-item>
        <el-form-item prop="manufactor">
          <el-input v-model="vaccines.manufactor" placeholder="请输入生产厂家"></el-input>
        </el-form-item>
        <el-form-item>
          <el-date-picker v-model="vaccines.mdate" type="date" value-format="yyyy-MM-dd" placeholder="选择日期">
          </el-date-picker>
        </el-form-item>
        <el-form-item prop="instructions">
          <el-input v-model="vaccines.instructions" type="textarea" placeholder="使用说明"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="addFlag = false">取 消</el-button>
        <el-button type="primary" @click="save">确 定</el-button>
      </div>
    </el-dialog>
    <!-- 定义修改对话框 -->
    <el-dialog title="修改预约地址信息" :visible.sync="editFlag">
      <el-form :model="vaccines" :rules="rules" ref="vaccines">
        <el-form-item prop="avcname">
          <el-input v-model="vaccines.avcname" placeholder="请输入疫苗名称"></el-input>
        </el-form-item>
        <el-form-item prop="price">
          <el-input v-model="vaccines.price" placeholder="请输入价格"></el-input>
        </el-form-item>
        <el-form-item prop="manufactor">
          <el-input v-model="vaccines.manufactor" placeholder="请输入生产厂家"></el-input>
        </el-form-item>
        <el-form-item>
          <el-date-picker v-model="vaccines.mdate" type="date" value-format="yyyy-MM-dd" placeholder="选择日期">
          </el-date-picker>
        </el-form-item>
        <el-form-item prop="instructions">
          <el-input v-model="vaccines.instructions" type="textarea" placeholder="使用说明"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="editFlag = false">取 消</el-button>
        <el-button type="primary" @click="update">确 定</el-button>
      </div>
    </el-dialog>

  </el-card>
</template>

<script>
  export default { //对外暴露vue对象
    data() { //定义的是vue对象的属性
      return {
        rules: {
          instructions: [{
            required: true,
            message: '该字段必填',
            trigger: 'blur'
          }],
          manufactor: [{
            required: true,
            message: '该字段必填',
            trigger: 'blur'
          }],
          price: [{
            required: true,
            message: '该字段必填',
            trigger: 'blur'
          }],
          avcname: [{
            required: true,
            message: '该字段必填',
            trigger: 'blur'
          }]
        },
        addFlag: false, //定义显示添加对话框的显示标记
        editFlag: false, //定义显示修改对话框的显示标记
        tableData: [], //定义表格中的数据，是一个数组
        pager: { //分页参数传递的pager对象
          page: 1, //从第一条开始分页
          size: 5, //每页显示10条记录
          total: 0 //分页总记录数
        },

        avcname: '', //根据疫苗名查询
        vaccines: {
          avcname: '',
          instructions: '',
          manufactor: '',
          mdate: '',
          price: '',
          avcid: 0
        }

      }
    },
    methods: { //用户自定义方法，在此编写
      openAddDialog() { //打开添加对话框
        this.addFlag = !this.addFlag;
      },
      openEditDialog(row) { //弹出修改对话框
        this.editFlag = !this.editFlag; //打开修改对话框
        this.vaccines = row; //填充修改对象数据
      },
      update() {
        this.$refs['vaccines'].validate(valid => {
          if (valid) {
            this.$http.post('http://127.0.0.1/vaccines/update', this.vaccines)
              .then(res => {
                if (res.data.code == 200) {
                  this.$message({
                    message: res.data.message,
                    type: 'success'
                  });
                  this.editFlag = !this.editFlag; //关闭对话代码
                  this.listPage();
                  this.vaccines = {}; //情况json对象数据
                }
              }).catch(e => {
                this.$message.error('错了哦，服务器端未启动');
              })
          }
        })
      },
      save() {
        this.$refs['vaccines'].validate(valid => {
          if (valid) {
            this.$http.post('http://127.0.0.1/vaccines/save', this.vaccines)
              .then(res => {
                if (res.data.code == 200) {
                  this.$message({
                    message: res.data.message,
                    type: 'success'
                  });
                  this.editFlag = !this.editFlag; //关闭对话代码
                  this.listPage();
                  this.vaccines = {}; //情况json对象数据
                }
              }).catch(e => {
          this.$message.error('错了哦，服务器端未启动');
        })
          }
        })
      },
      remove(row) {
        this.$http.post('http://127.0.0.1/vaccines/remove?avcid=' + row.avcid)
          .then(res => {
            if (res.data.code == 200) {
              this.$message({
                message: res.data.message,
                type: 'success'
              });
              this.listPage();
            }
          }).catch(e => {
          this.$message.error('错了哦，服务器端未启动');
        })

      },

      handleCurrentChange(val) {
        console.info('改变分页起始数据' + val)
        this.pager.page = val; //分页起始数据赋值
        this.listPage() //再次调佣分页方法
      },
      handleSizeChange(val) {
        console("改变每页显示的最大条数" + val);
        this.pager.size = val; //改变最大的分页数
        this.listPage(); //再次调佣分页方法
      },
      listPage() { //定义分页方法
        this.$http.get('http://127.0.0.1/vaccines/listPage', {
          params: {
            page: this.pager.page,
            size: this.pager.size,
            avcname: this.avcname
          }
        }).then(res => {
          console.info(res);
          this.tableData = res.data.data.data; //查询出的数据
          this.pager.total = res.data.data.count; //返回分页统计记录数
        }).catch(e => {
          this.$message.error('错了哦，服务器端未启动');
        })
      }

    },
    created() { //浏览器在渲染时立即执行该方法中的代码
      this.listPage();
    }
  }
</script>

<style>
  .el-breadcrumb {
    padding-bottom: 12px;

  }

  .el-pagination {
    padding-top: 12px;
  }
</style>
