<template>
  <!-- 定义的卡片组件 -->
  <el-card>
    <!-- 面包屑组件 -->
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item :to="{path:'/welcome'}">首页</el-breadcrumb-item>
      <el-breadcrumb-item>用户地点管理</el-breadcrumb-item>
      <el-breadcrumb-item>预约地点管理</el-breadcrumb-item>
    </el-breadcrumb>
    <!-- 面板布局 -->
    <el-row :gutter="12">
      <el-col :span="6">
        <!-- 输入框组件 -->
        <el-input clearable @clear="listPage" v-model="address" placeholder="请输入预约地址查询"></el-input>
      </el-col>
      <el-col :span="6">
        <!-- 按钮组件 -->
        <el-button type="primary" icon="el-icon-search" @click="listPage">查询</el-button>
        <el-button type="success" icon="el-icon-plus" @click="openAddDialog">添加</el-button>
      </el-col>
    </el-row>
    <!-- 定义表格组件 -->
    <el-table :data="tableData">
      <el-table-column prop="address" label="预约地址"></el-table-column>
      <el-table-column prop="detail" label="详情"></el-table-column>
      <el-table-column prop="tel" label="电话"></el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-tooltip content="点击修改" placement="left">
            <el-button type="warning" circle icon="el-icon-edit" @click="openEditDialog(scope.row)"></el-button>
          </el-tooltip>
          <el-tooltip content="点击删除" placement="right">
            <el-button type="danger" circle icon="el-icon-delete" @click="remove(scope.row)"></el-button>
          </el-tooltip>
        </template>
      </el-table-column>
    </el-table>
    <!-- 分页组件定义 -->
    <el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange" :current-page="pager.page"
      :page-sizes="[5, 10, 15, 20]" :page-size="pager.size" layout="total, sizes, prev, pager, next, jumper"
      :total="pager.total">
    </el-pagination>

    <!-- 添加对话框定义 -->
    <el-dialog :visible.sync="addFlag" title="添加预约地址信息">
      <el-form :model="addresss" :rules="rules" ref="addresss">
        <el-form-item prop="address">
          <el-input v-model="addresss.address" placeholder="请输入预约地址信息"></el-input>
        </el-form-item>
        <el-form-item prop="tel">
          <el-input v-model="addresss.tel" placeholder="请输入预约地址电话信息"></el-input>
        </el-form-item>
        <el-form-item prop="detail">
          <el-input v-model="addresss.detail" type="textarea" placeholder="请输入预约地址详情"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="addFlag = false">取 消</el-button>
        <el-button type="primary" @click="save">确 定</el-button>
      </div>
    </el-dialog>
    <!-- 定义修改对话框 -->
    <el-dialog title="修改预约地址信息" :visible.sync="editFlag">
      <el-form :model="addresss" :rules="rules" ref="addresss">
        <el-form-item prop="address">
          <el-input v-model="addresss.address" placeholder="请输入预约地址信息"></el-input>
        </el-form-item>
        <el-form-item prop="tel">
          <el-input v-model="addresss.tel" placeholder="请输入预约地址电话信息"></el-input>
        </el-form-item>
        <el-form-item prop="detail">
          <el-input v-model="addresss.detail" type="textarea" placeholder="请输入预约地址详情"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="editFlag = false">取 消</el-button>
        <el-button type="primary" @click="update">确 定</el-button>
      </div>
    </el-dialog>

  </el-card>
</template>

<script>
  export default { //对外暴露vue对象
    data() { //定义的是vue对象的属性
      return {
        rules: {
          address: [{
            required: true,
            message: '该字段必填',
            trigger: 'blur'
          }],
          tel: [{
            required: true,
            message: '该字段必填',
            trigger: 'blur'
          }],
          detail: [{
            required: true,
            message: '该字段必填',
            trigger: 'blur'
          }]
        },
        addFlag: false, //定义显示添加对话框的显示标记
        editFlag: false, //定义显示修改对话框的显示标记
        tableData: [], //定义表格中的数据，是一个数组
        pager: { //分页参数传递的pager对象
          page: 1, //从第一条开始分页
          size: 5, //每页显示10条记录
          total: 0 //分页总记录数
        },

        address: '', //根据预约地址进行条件查询
        addresss: { //封装预约地址以对象形式封装数据
          addid: 0,
          address: '',
          detail: '',
          tel: ''
        }

      }
    },
    methods: { //用户自定义方法，在此编写
      openAddDialog() { //打开添加对话框
        this.addFlag = !this.addFlag;
      },
      openEditDialog(row) { //弹出修改对话框

        this.editFlag = !this.editFlag; //打开修改对话框
        this.addresss = row; //填充修改对象数据

      },
      update() {
        this.$refs['addresss'].validate(valid => {
          if (valid) {
            this.$http.post('http://127.0.0.1/address/update', this.addresss)
              .then(res => {
                if (res.data.code == 200) {
                  this.$message({
                    message: res.data.message,
                    type: 'success'
                  });
                  this.editFlag = !this.editFlag; //关闭对话代码
                  this.listPage();
                  this.addresss = {}; //情况json对象数据
                }
              }).catch(e => {
                this.$message.error('错了哦，服务器端未启动');
              })
          }
        })

      },
      save() {
        this.$refs['addresss'].validate(valid => {
          if (valid) {
            this.$http.post('http://127.0.0.1/address/save', this.addresss)
              .then(res => {
                if (res.data.code == 200) {
                  this.$message({
                    message: res.data.message,
                    type: 'success'
                  });
                  this.addFlag = !this.addFlag; //关闭对话代码
                  this.listPage();
                  this.addresss = {}; //情况json对象数据
                }
              }).catch(e => {
                this.$message.error('错了哦，服务器端未启动');
              })
          }

        })

      },
      remove(row) {
        this.$http.post('http://127.0.0.1/address/remove?addid=' + row.addid)
          .then(res => {
            if (res.data.code == 200) {
              this.$message({
                message: res.data.message,
                type: 'success'
              });
              this.listPage();
            }
          }).catch(e => {
            this.$message.error('错了哦，服务器端未启动');
          })

      },

      handleCurrentChange(val) {
        console.info('改变分页起始数据' + val)
        this.pager.page = val; //分页起始数据赋值
        this.listPage() //再次调佣分页方法
      },
      handleSizeChange(val) {
        console("改变每页显示的最大条数" + val);
        this.pager.size = val; //改变最大的分页数
        this.listPage(); //再次调佣分页方法
      },
      listPage() { //定义分页方法
        this.$http.get('http://127.0.0.1/address/listPage', {
          params: {
            page: this.pager.page,
            size: this.pager.size,
            address: this.address
          }
        }).then(res => {
          console.info(res);
          this.tableData = res.data.data.data; //查询出的数据
          this.pager.total = res.data.data.count; //返回分页统计记录数
        }).catch(e => {
          this.$message.error('错了哦，服务器端未启动');
        })
      }

    },
    created() { //浏览器在渲染时立即执行该方法中的代码
      this.listPage();
    }
  }
</script>

<style>
  .el-breadcrumb {
    padding-bottom: 12px;

  }

  .el-pagination {
    padding-top: 12px;
  }
</style>
