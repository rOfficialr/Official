package com.vrms.app.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
@Data
@ApiModel
public class Appointment implements Serializable {
    private static final long serialVersionUID = 774526297519125857L;
    /**
     * 预约ID
     */
    @ApiModelProperty(hidden = true)
    private Integer appid;
    /**
     * 用户外键
     */
    @ApiModelProperty(name = "uid",value = "预约外键",example = "1",
            dataType = "integer",required = true)
    private Integer uid;

    @ApiModelProperty(hidden = true)
    //预约人
    private String username;
    /**
     * 预约地址外键
     */
    @ApiModelProperty(name = "addid",value = "预约地址外键",example = "1",
            dataType = "integer",required = true)
    private Integer addid;

    @ApiModelProperty(hidden = true)
    //预约地址
    private String address;
    /**
     * 疫苗外键
     */
    @ApiModelProperty(name = "avcid",value = "疫苗外键",example = "1",
            dataType = "integer",required = true)
    private Integer avcid;

    @ApiModelProperty(hidden = true)
    //疫苗名称
    private String avcname;
    /**
     * 支付金额
     */
    @ApiModelProperty(name = "money",value = "付款",example = "1",
            dataType = "string")
    private String money;
    /**
     * 预约状态 0已预约、1已取消
     */
    @ApiModelProperty(name = "appstats",value = "预约状态",example = "0",
            dataType = "string")
    private Integer appstats;
    /**
     * 预约时间
     */
    @ApiModelProperty(name = "apptime",value = "预约时间",example = "2021-12-28 18:00:01",
            dataType = "string")
    private String apptime;
    /**
     * 接种状态 0未接种、1已接种
     */
    @ApiModelProperty(name = "stats",value = "接种状态",example = "0",
            dataType = "string")
    private Integer stats;
    /**
     * 创建时间
     */
    @ApiModelProperty(hidden = true)
    private String ctime;
    /**
     * 修改时间
     */
    @ApiModelProperty(hidden = true)
    private String mtime;
    /**
     * 0未删除 1已删除
     */
    @ApiModelProperty(hidden = true)
    private Integer deleted;
    /**
     * 备注
     */
    @ApiModelProperty(name ="remark",value = "备注",
            example = "说明情况",dataType = "string")
    private String remark;


}

