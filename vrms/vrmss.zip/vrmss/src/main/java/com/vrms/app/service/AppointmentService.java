package com.vrms.app.service;


import com.vrms.app.entity.Appointment;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface AppointmentService {

    List<Appointment> listPage(@Param("page") int page,
                               @Param("size")int size,
                               @Param("username")String username);

    int count(@Param("username")String username);

    boolean save(Appointment appointment);

    boolean update(Appointment appointment);

    boolean remove(int appid);

}
