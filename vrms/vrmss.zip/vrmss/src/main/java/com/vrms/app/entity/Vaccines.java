package com.vrms.app.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class Vaccines implements Serializable {
    private static final long serialVersionUID = -49765971847729008L;
    /**
     * 疫苗ID
     */
    @ApiModelProperty(hidden = true)
    private Integer avcid;
    /**
     * 疫苗名称
     */
    @ApiModelProperty(name ="avcname",value = "疫苗名称",
            example = "科兴新冠肺炎疫苗",dataType ="string",required = true )
    private String avcname;
    /**
     * 生成厂家
     */
    @ApiModelProperty(name ="manufactor",value = "生产厂家",
            example = "北京科兴",dataType ="string",required = true )
    private String manufactor;
    /**
     * 生产日期
     */
    @ApiModelProperty(name ="mdate",value = "生产日期",
            example = "2021-12-28",dataType ="string",required = true )
    private String mdate;
    /**
     * 单价
     */
    @ApiModelProperty(name ="price",value = "单价",
            example = "60",dataType ="string",required = true )
    private String price;
    /**
     * 说明
     */
    @ApiModelProperty(name ="instructions",value = "说明",
            example = "使用说明",dataType ="string",required = true )
    private String instructions;
    /**
     * 创建时间
     */
    @ApiModelProperty(hidden = true)
    private String ctime;
    /**
     * 修改时间
     */
    @ApiModelProperty(hidden = true)
    private String mtime;
    /**
     * 0未删除 1已删除
     */
    @ApiModelProperty(hidden = true)
    private Integer deleted;
}

