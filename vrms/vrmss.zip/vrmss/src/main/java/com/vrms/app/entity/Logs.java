package com.vrms.app.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel
public class Logs implements Serializable {
    private static final long serialVersionUID = -89998567097386518L;
    /**
     * 日志ID
     */
    @ApiModelProperty(hidden = true)
    private Integer opid;
    /**
     * 操作时间
     */
    @ApiModelProperty(name = "optime",value = "操作时间",
            dataType = "string",example = "2021-12-28")
    private String optime;
    /**
     * 操作ip
     */
    @ApiModelProperty(name = "ip",value = "操作IP",
            dataType = "string",example = "192.168.1.1")
    private String ip;
    /**
     * 操作方法
     */
    @ApiModelProperty(name = "methods",value = "操作方法",
            dataType = "string",example = "save")
    private String methods;
    /**
     * 操作方法描述
     */
    @ApiModelProperty(name = "ddesc",value = "操作方法描述",
            dataType = "string",example = "添加xxx数据")
    private String ddesc;



}

