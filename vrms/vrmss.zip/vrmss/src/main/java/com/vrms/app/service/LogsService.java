package com.vrms.app.service;

import com.vrms.app.entity.Logs;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface LogsService {


    List<Logs> listPage(@Param("page") int page,
                        @Param("size") int size);

    int count();

    boolean save(Logs logs);

}
