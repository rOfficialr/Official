package com.vrms.app.service;


import com.vrms.app.entity.Address;

import java.util.List;

public interface AddressService {

    /**
     * 分页查询预约地址信息
     * @param page
     * @param size
     * @param address
     * @return
     */
    List<Address> listPage(int page,int size,
                            String address);

    /**
     * 全查疫苗预约地址信息
     * @return
     */
    List<Address> list();

    /**
     * 统计预约地址信息，分页使用
     * @param address
     * @return
     */
    int count(String address);

    /**
     * 添加预约地址信息
     * @param address
     * @return
     */
    boolean save(Address address);

    /**
     * 更新预约地址信息
     * @param address
     * @return
     */
    boolean update(Address address);

    /**
     * 根据ID删除预约地址信息
     * @param addid
     * @return
     */
    boolean remove(int addid);


}
