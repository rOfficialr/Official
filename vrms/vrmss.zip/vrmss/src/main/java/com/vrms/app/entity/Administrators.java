package com.vrms.app.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
@ApiModel //表明这是封装数据的模型标签，该标签是swagger提供的api注解标签，该标签必须放置在类的头部使用
public class Administrators implements Serializable {
    private static final long serialVersionUID = 241444062314274701L;
    /**
     * 管理员ID
     */
    //模型中的属性使用该标签注解，也是swagger提供的api注解标签
    @ApiModelProperty(name = "aid",value = "管理员对象标识",
            hidden = true,dataType = "integer",example = "1")
    private Integer aid;
    /**
     * 用户名称
     */
    @ApiModelProperty(name = "username",value = "管理员名称",
            required = true,dataType = "string",example = "admin")
    private String username;
    /**
     * 用户密码
     */
    @ApiModelProperty(name = "password",value = "管理员密码",
            required = true,dataType = "string",example = "000000")
    private String password;
    /**
     * 头像
     */
    @ApiModelProperty(name = "images",value = "管理员头像",
            required = true,dataType = "string",example = "000000")
    private String images;
    /**
     * 状态
     */
    @ApiModelProperty(name = "stats",value = "状态",
            required = true,dataType = "integer",example = "0")
    private Integer stats;
    /**
     * 创建时间
     */
    @ApiModelProperty(hidden = true)
    private String ctime;
    /**
     * 修改时间
     */
    @ApiModelProperty(hidden = true)
    private String mtime;
    /**
     * 0未删除,1已删除
     */
    @ApiModelProperty(hidden = true)
    private Integer deleted;

}

